export interface Bibliography {
    id: number;
    name: string;
}

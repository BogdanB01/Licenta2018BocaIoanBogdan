package com.license.smapp.boundry.dto;

public class LecturerDto extends UserDto {
    private String cabinetNumber;

    public String getCabinetNumber() {
        return cabinetNumber;
    }

    public void setCabinetNumber(String cabinetNumber) {
        this.cabinetNumber = cabinetNumber;
    }
}

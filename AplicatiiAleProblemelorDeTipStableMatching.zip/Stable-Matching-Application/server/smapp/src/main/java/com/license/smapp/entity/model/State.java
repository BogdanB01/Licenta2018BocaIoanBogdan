package com.license.smapp.entity.model;

public enum  State {
    OPENED,
    CLOSED
}

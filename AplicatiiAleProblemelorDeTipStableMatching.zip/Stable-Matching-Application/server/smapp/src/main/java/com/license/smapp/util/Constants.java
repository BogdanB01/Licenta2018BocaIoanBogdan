package com.license.smapp.util;

public class Constants {
    public static final String STUDENT_USER = "ROLE_STUDENT";
    public static final String LECTURER_USER = "ROLE_LECTURER";
    public static final Long STATE_ID = 1L;
}

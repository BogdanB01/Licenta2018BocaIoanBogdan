package com.license.smapp.entity.repository;

import com.license.smapp.entity.model.Bibliography;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BibliographyRepository extends JpaRepository<Bibliography, Long> {

}

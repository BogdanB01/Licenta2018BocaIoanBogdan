package com.license.smapp.control.service;

import com.license.smapp.entity.model.Answer;

public interface AnswerService extends CrudService<Answer>{

}

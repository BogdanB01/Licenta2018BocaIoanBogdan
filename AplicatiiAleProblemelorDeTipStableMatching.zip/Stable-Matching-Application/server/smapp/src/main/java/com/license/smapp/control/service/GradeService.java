package com.license.smapp.control.service;

import com.license.smapp.entity.model.Grade;

public interface GradeService extends CrudService<Grade> {
}

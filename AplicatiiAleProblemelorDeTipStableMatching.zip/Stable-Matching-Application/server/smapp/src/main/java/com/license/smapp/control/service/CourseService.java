package com.license.smapp.control.service;

import com.license.smapp.entity.model.Course;

public interface CourseService extends CrudService<Course> {
    void deleteAll();
}
